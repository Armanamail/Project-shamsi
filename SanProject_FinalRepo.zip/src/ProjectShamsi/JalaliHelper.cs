using System;
using System.Globalization;

namespace ProjectShamsi
{
    public static class JalaliHelper
    {
        private static readonly PersianCalendar pc = new PersianCalendar();
        private static readonly string[] Months = { "فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند" };
        private static readonly string[] WeekDays = { "شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنج‌شنبه","جمعه" };

        public static string ToDateString(DateTime dt)
        {
            int y = pc.GetYear(dt), m = pc.GetMonth(dt), d = pc.GetDayOfMonth(dt);
            return string.Format("{0:0000}/{1:00}/{2:00}", y, m, d);
        }

        public static string MonthName(int month) => Months[month-1];

        public static string SeasonLabel(DateTime dt)
        {
            int m = pc.GetMonth(dt), y = pc.GetYear(dt);
            if (m>=1 && m<=3) return $"بهار {y}";
            if (m>=4 && m<=6) return $"تابستان {y}";
            if (m>=7 && m<=9) return $"پاییز {y}";
            return $"زمستان {y}";
        }

        public static string HalfYearLabel(DateTime dt)
        {
            int m = pc.GetMonth(dt), y = pc.GetYear(dt);
            return m<=6 ? $"نیمسال اول {y}" : $"نیمسال دوم {y}";
        }

        public static string WeekdayName(DateTime dt) => WeekDays[(int)dt.DayOfWeek];
    }
}

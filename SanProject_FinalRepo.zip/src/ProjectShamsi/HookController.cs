namespace ProjectShamsi
{
    public class HookController
    {
        private HookManager _hm;
        public HookController() { _hm = new HookManager(); }
        public void Install() { _hm.Install(); }
        public void Uninstall() { _hm.Uninstall(); }
    }
}

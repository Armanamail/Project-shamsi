using System;
using Microsoft.Office.Interop.MSProject;

namespace ProjectShamsi
{
    public partial class ThisAddIn
    {
        private HookController _hookController;

        private void ThisAddIn_Startup(object sender, EventArgs e)
        {
            _hookController = new HookController();
            _hookController.Install();
        }

        private void ThisAddIn_Shutdown(object sender, EventArgs e)
        {
            try { _hookController?.Uninstall(); } catch { }
        }
    }
}

ProjectShamsi (سان پراجکت) - Ready for GitHub Actions. Push to main to build MSI and ZIP artifacts.
